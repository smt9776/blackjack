#!/bin/bash
# Reference for why we need to do this: https://veithen.github.io/2014/11/16/sigterm-propagation.html

if [ "$1" = "p" ]; then
  RUN="Player"
elif [ "$1" = "d" ]; then
  RUN="Dealer"
elif [ "$1" = "s" ]; then
  RUN="Snooper"
elif [ "$1" = "kill" ]; then
  echo "Killing all stalled java processes..."
  killall -9 java
  exit 0
else
  echo "Invalid argument! Takes: p, d, s, or kill_java"
  exit 1
fi

echo "Running: $RUN"
exec java -classpath $OSPL_HOME/jar/dcpssaj.jar:classes $RUN
