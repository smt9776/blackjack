package CR;

public interface MAX_PLAYERS {
    public static final int value = (int)(6);
}
