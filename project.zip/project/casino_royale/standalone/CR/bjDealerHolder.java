package CR;

public final class bjDealerHolder
{

    public CR.bjDealer value = null;

    public bjDealerHolder () { }

    public bjDealerHolder (CR.bjDealer initialValue)
    {
        value = initialValue;
    }

}
