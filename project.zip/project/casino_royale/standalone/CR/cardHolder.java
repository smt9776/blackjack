package CR;

public final class cardHolder
{

    public CR.card value = null;

    public cardHolder () { }

    public cardHolder (CR.card initialValue)
    {
        value = initialValue;
    }

}
