package CR;

public final class bjDealerTypeSupportHolder
{

    public CR.bjDealerTypeSupport value = null;

    public bjDealerTypeSupportHolder()
    {
    }

    public bjDealerTypeSupportHolder(CR.bjDealerTypeSupport initialValue)
    {
        value = initialValue;
    }

}
