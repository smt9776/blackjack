package CR;

public final class bjPlayerMetaHolder
{

    public static java.lang.String metaDescriptor[] = { "<MetaData version=\"1.0.0\"><Module name=\"CR\"><Enum name=\"bjp_action\"><Element name=\"none\" value=\"0\"/><Element name=\"joining\" value=\"1\"/><Element name=\"exiting\" value=\"2\"/><Element name=\"wagering\" value=\"3\"/><Element name=\"requesting_a_card\" value=\"4\"/></Enum><Struct name=\"bjPlayer\"><Member name=\"uuid\"><Long/></Member><Member name=\"seqno\"><Long/></Member><Member name=\"credits\"><Float/></Member><Member name=\"wager\"><Long/></Member><Member name=\"dealer_id\"><Long/></Member><Member name=\"action\"><Type name=\"bjp_action\"/></Member></Struct></Module></MetaData>" };

    public bjPlayerMetaHolder()
    {
    }

}
