package CR;

public final class bjPlayerTypeSupportHolder
{

    public CR.bjPlayerTypeSupport value = null;

    public bjPlayerTypeSupportHolder()
    {
    }

    public bjPlayerTypeSupportHolder(CR.bjPlayerTypeSupport initialValue)
    {
        value = initialValue;
    }

}
