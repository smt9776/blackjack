package CR;

public final class bjPlayerDataReaderHolder
{

    public CR.bjPlayerDataReader value = null;

    public bjPlayerDataReaderHolder()
    {
    }

    public bjPlayerDataReaderHolder(CR.bjPlayerDataReader initialValue)
    {
        value = initialValue;
    }

}
