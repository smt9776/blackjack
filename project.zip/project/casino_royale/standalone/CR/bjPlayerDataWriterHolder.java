package CR;

public final class bjPlayerDataWriterHolder
{

    public CR.bjPlayerDataWriter value = null;

    public bjPlayerDataWriterHolder()
    {
    }

    public bjPlayerDataWriterHolder(CR.bjPlayerDataWriter initialValue)
    {
        value = initialValue;
    }

}
