package CR;

public interface bjDealerDataWriter extends
    CR.bjDealerDataWriterOperations,
    DDS.DataWriter
{
}
