package CR;

public interface bjPlayerDataReaderView extends
    CR.bjPlayerDataReaderViewOperations,
    DDS.DataReaderView
{
}
