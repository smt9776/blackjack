package CR;

public final class bjPlayerHolder
{

    public CR.bjPlayer value = null;

    public bjPlayerHolder () { }

    public bjPlayerHolder (CR.bjPlayer initialValue)
    {
        value = initialValue;
    }

}
