package CR;

public final class player_statusHolder
{

    public CR.player_status value = null;

    public player_statusHolder () { }

    public player_statusHolder (CR.player_status initialValue)
    {
        value = initialValue;
    }

}
