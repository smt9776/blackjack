package CR;

public final class bjDealerDataReaderHolder
{

    public CR.bjDealerDataReader value = null;

    public bjDealerDataReaderHolder()
    {
    }

    public bjDealerDataReaderHolder(CR.bjDealerDataReader initialValue)
    {
        value = initialValue;
    }

}
