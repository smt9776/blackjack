package CR;

public interface bjDealerDataReader extends
    CR.bjDealerDataReaderOperations,
    DDS.DataReader
{
}
