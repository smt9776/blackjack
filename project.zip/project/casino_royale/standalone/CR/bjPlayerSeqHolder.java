package CR;

public final class bjPlayerSeqHolder
{

    public CR.bjPlayer value[] = null;

    public bjPlayerSeqHolder()
    {
    }

    public bjPlayerSeqHolder(CR.bjPlayer[] initialValue)
    {
        value = initialValue;
    }

}
