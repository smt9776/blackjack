package CR;

public interface bjDealerDataReaderView extends
    CR.bjDealerDataReaderViewOperations,
    DDS.DataReaderView
{
}
