package CR;

public final class bjDealerSeqHolder
{

    public CR.bjDealer value[] = null;

    public bjDealerSeqHolder()
    {
    }

    public bjDealerSeqHolder(CR.bjDealer[] initialValue)
    {
        value = initialValue;
    }

}
