package CR;

public final class bjDealerDataWriterHolder
{

    public CR.bjDealerDataWriter value = null;

    public bjDealerDataWriterHolder()
    {
    }

    public bjDealerDataWriterHolder(CR.bjDealerDataWriter initialValue)
    {
        value = initialValue;
    }

}
