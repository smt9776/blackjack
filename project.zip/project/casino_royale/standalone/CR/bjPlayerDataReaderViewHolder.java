package CR;

public final class bjPlayerDataReaderViewHolder
{

    public CR.bjPlayerDataReaderView value = null;

    public bjPlayerDataReaderViewHolder()
    {
    }

    public bjPlayerDataReaderViewHolder(CR.bjPlayerDataReaderView initialValue)
    {
        value = initialValue;
    }

}
