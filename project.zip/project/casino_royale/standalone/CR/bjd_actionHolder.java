package CR;

public final class bjd_actionHolder
{

    public CR.bjd_action value = null;

    public bjd_actionHolder () { }

    public bjd_actionHolder (CR.bjd_action initialValue)
    {
        value = initialValue;
    }

}
