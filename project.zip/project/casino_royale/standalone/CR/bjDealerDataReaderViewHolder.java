package CR;

public final class bjDealerDataReaderViewHolder
{

    public CR.bjDealerDataReaderView value = null;

    public bjDealerDataReaderViewHolder()
    {
    }

    public bjDealerDataReaderViewHolder(CR.bjDealerDataReaderView initialValue)
    {
        value = initialValue;
    }

}
