package CR;

public interface bjPlayerDataReader extends
    CR.bjPlayerDataReaderOperations,
    DDS.DataReader
{
}
