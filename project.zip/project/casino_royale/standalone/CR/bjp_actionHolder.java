package CR;

public final class bjp_actionHolder
{

    public CR.bjp_action value = null;

    public bjp_actionHolder () { }

    public bjp_actionHolder (CR.bjp_action initialValue)
    {
        value = initialValue;
    }

}
