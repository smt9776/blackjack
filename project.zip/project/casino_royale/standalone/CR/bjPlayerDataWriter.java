package CR;

public interface bjPlayerDataWriter extends
    CR.bjPlayerDataWriterOperations,
    DDS.DataWriter
{
}
