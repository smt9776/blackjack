// The following code modified from from PrismTech HelloWorld example

/*
Group: 7
Members: Climon Galunza, Sheba Thomas, Hiumathy Lam
Date Modified: November 19, 2016
*/

import DDS.*;
import CR.*;
import java.util.*;

public class Dealer {
	//This code is used to test a win or lose situation (REMOVE LATER!!!!)
	public static int randInt(int min, int max) {

		// Usually this can be a field rather than a method variable
		Random rand = new Random();

		// nextInt is normally exclusive of the top value,
		// so add 1 to make it inclusive
		int randomNum = rand.nextInt((max - min) + 1) + min;

		return randomNum;
	}

	public static int intValue(char val) {

		int total;
		// im assuming this is for the first hand?
		switch (val) {
			case 'K':  total = 10;
				break;
			case 'Q':  total =10;
				break;
			case 'J':  total =10;
				break;
			case 'T':  total =10;
				break;
			case 'A':  total = 11; // not sure how to work with the Ace values of 11 or 1 depending on the hand
				break;
			case '2':  total = 2;
				break;
			case '3':  total = 3;
				break;
			case '4':  total = 4;
				break;
			case '5':  total = 5;
				break;
			case '6':  total = 6;
				break;
			case '7':  total = 7;
				break;
			case '8':  total = 8;
				break;
			case '9':  total = 9;
				break;
			default: total = 0;
				break;
		}
		//System.out.println("Total = " + total);
		return total;
	}

	public static int cardGame(char value, int total){
		total = intValue(value);
		return total;
	}
	
	public static void shuffle(Object[] a) {
        int n = a.length;
        for (int i = 0; i < n; i++) {
            // between i and n-1
            int r = i + (int) (Math.random() * (n - i));
            Object tmp = a[i];    // swap
            a[i] = a[r];
            a[r] = tmp;
        }
	}

    public static void main(String[] args) {
		DDSEntityManager mgr2 = new DDSEntityManager();
		String partitionName = "Casino Royale";

		mgr2.createParticipant(partitionName);

		bjPlayerTypeSupport bjPlayerTS = new bjPlayerTypeSupport();
		mgr2.registerType(bjPlayerTS);

		mgr2.createTopic("CR_bjPlayer");

		mgr2.createSubscriber();

		mgr2.createReader();

		DataReader dreader2 = mgr2.getReader();
		bjPlayerDataReader CRReader2 = bjPlayerDataReaderHelper.narrow(dreader2);

		bjPlayerSeqHolder bjPlayerSeq = new bjPlayerSeqHolder();
		SampleInfoSeqHolder infoSeq2 = new SampleInfoSeqHolder();

		//make deck for dealer
		card[] cards = new card[312];


		//fill decks with data
		int x;
		char[] values = {'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T',
				'A', 'J', 'Q', 'K', '2', '3', '4', '5', '6', '7', '8', '9', 'T'};

		char[] suites = {'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C',
				'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H',
				'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D',
				'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S',
				'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C',
				'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H',
				'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D',
				'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S',
				'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C',
				'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H',
				'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D',
				'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S',
				'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C',
				'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H',
				'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D',
				'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S',
				'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C',
				'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H',
				'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D',
				'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S',
				'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C',
				'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H',
				'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D',
				'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S'};


		for (x = 0; x < 312; x++) {
			cards[x] = new card();
		}

		for (x = 0; x < 312; x++) {
			cards[x].visible = false;
			cards[x].suite = suites[x];
			cards[x].base_value = values[x];
		}

		//test shuffe (remove later)
		/*
		shuffle(cards);
		for(x = 0; x < 52; x++){
				System.out.println(cards[x].suite + " " + cards[x].base_value);
		}
		*/

		//make new dealer
		Dealer deal = new Dealer(); // Dynamic class object //What's this?
		bjDealer bjDealerInstance = new bjDealer();


		bjDealerInstance.uuid = 1111;
		bjDealerInstance.seqno = 1;
		bjDealerInstance.active_players = 0;
		bjDealerInstance.action = bjd_action.waiting; // Dealer default waiting state
		bjDealerInstance.target_uuid = 1000; // set the default target_uuid

		deal.publish(bjDealerInstance);

		int num_games = 0;


		//Dealer is waiting for player to join the game
		System.out.println("Dealer is waiting for player to join a game...");
		while (true) {
			CRReader2.read(bjPlayerSeq, infoSeq2, LENGTH_UNLIMITED.value,
					ANY_SAMPLE_STATE.value, 1,
					ANY_INSTANCE_STATE.value);

			if (num_games == 5) {
				System.out.println("Game is over! Player has left.");
				break;
			}

			for (int i = 0; i < bjPlayerSeq.value.length; i++) {
				/*
                System.out.println("=== [Player] message received :");
                System.out.println("    uuid           : " + bjPlayerSeq.value[i].uuid);
                System.out.println("    seqno          : " + bjPlayerSeq.value[i].seqno);
                System.out.println("    credits        : " + bjPlayerSeq.value[i].credits);
                System.out.println("    wager          : " + bjPlayerSeq.value[i].wager);
                System.out.println("    dealer_id      : " + bjPlayerSeq.value[i].dealer_id);
                System.out.println("    action         : " + bjPlayerSeq.value[i].action.value());
				*/

				//1) if a player is found
				if (bjPlayerSeq.value[i].action.value() == 1) {
					System.out.printf("Player ID %d, has now joined the game\n", bjPlayerSeq.value[i].uuid);
					//Add an active player to Dealer
					bjDealerInstance.active_players++;
					// player status
					player_status p = new player_status();
					p.uuid = bjPlayerSeq.value[i].uuid;
					p.wager = bjPlayerSeq.value[i].wager;
					p.payout = 0;  //This will change after cards have been compared
					//dealer and player don't have cards yet
					bjDealerInstance.players[i] = p;
					deal.publish(bjDealerInstance);
				}
				//2) if a player is wagering
				if (bjPlayerSeq.value[i].action.value() == 3) {
					System.out.printf("Player ID %d has wagered: $%d\n", bjPlayerSeq.value[i].dealer_id, bjPlayerSeq.value[i].wager);
					bjDealerInstance.action = bjd_action.dealing;
					System.out.println("Dealer is now dealing for player\n");
					//change the player_status's cards and publish


					// HIU'S EDIT STARTS HERE ---------------------
					//shuffle cards
					shuffle(cards);
					
					
					//Hardcoded cards for player and dealer (Climon's Edit)
					int ind = 0, indP = 0;
					while(ind < 24){
							if(ind < 12){
								bjDealerInstance.cards[ind].suite = cards[ind].suite;
								bjDealerInstance.cards[ind].base_value = cards[ind].base_value;
								bjDealerInstance.cards[ind].visible = false;
								ind++;
							}
							else{
								bjDealerInstance.players[i].cards[indP].suite = cards[ind].suite;
								bjDealerInstance.players[i].cards[indP].base_value = cards[ind].base_value;
								bjDealerInstance.players[i].cards[indP].visible = false;
								indP++;
								ind++;
							}
					}
					// dealer gets two cards first (first card visible, second card is not)
					// dealer's first card
					System.out.println("Dealer's Cards...");
					bjDealerInstance.cards[0].visible = true;
					// dealer's second card
					bjDealerInstance.cards[1].visible = false;

					System.out.println(bjDealerInstance.cards[0].suite + ", " + bjDealerInstance.cards[0].base_value);
					System.out.println(bjDealerInstance.cards[1].suite + ", " + bjDealerInstance.cards[1].base_value);


					// players first card
					bjDealerInstance.players[i].cards[0].visible = true;
					// players second card
					bjDealerInstance.players[i].cards[1].visible = true;
				}


					// HIU'S EDIT ENDS HERE ------------------

					deal.publish(bjDealerInstance);
					//reaches this statement
					
					//3)If a player is decided
					if(bjPlayerSeq.value[i].action.value() == 0){
						//player status if won or lost
						//System.out.println("Hello"); //print statement use to find where statement is being reached
						int won = 1;
						
						//keep track of player total and dealer total
						int pTotal = 0, pCount = 0, seqcount = 0;
						boolean pBust = false, dBust = false;
						int dTotal = intValue(bjDealerInstance.cards[0].base_value) + intValue(bjDealerInstance.cards[1].base_value), dCount = 2;

						// ACES
						int aces=0;
						if ( bjDealerInstance.cards[0].base_value == 'A')
							aces++;
						if (bjDealerInstance.cards[1].base_value == 'A')
							aces++;

						if (dTotal > 21)                   // if two aces in a row
							if (aces > 0) {
								dTotal -= 10;
								aces--;
							}
							else if (pTotal == 21) 					// 21
								System.out.println("BLACKJACK");
						System.out.println("Dealer has "+ dTotal+"\n"); // print total

						//find player total
						while(seqcount < bjPlayerSeq.value[i].seqno){
								pTotal += intValue(bjDealerInstance.players[i].cards[seqcount].base_value);
								seqcount++;
						}
						
						System.out.printf("Player's Total is: %d\n", pTotal);
						
						//if players busts
						if(pTotal > 21){
								System.out.println("Player Busted!");
								pBust = true;
								won = 0;
						}


						
						//if player didn't bust count Dealer total
						if(!pBust){
							while(dTotal < 17){
								System.out.println("Dealer is drawing another card for himself...");
								System.out.println("Dealer Suite: " + bjDealerInstance.cards[dCount].suite + ", " + "Dealer Base Value: " + bjDealerInstance.cards[dCount].base_value);

								dTotal += intValue(bjDealerInstance.cards[dCount].base_value);
								if (bjDealerInstance.cards[dCount].base_value == 'A')
									aces++;
								if (dTotal > 21) { 							// bust
									if (aces > 0){
										dTotal -= 10;
										aces--;
									}
									else {
										System.out.println("Dealer Busted!");
										dBust = true;
										won = 1;
										System.out.printf("Dealer's Total is: %d\n", dTotal);
										break;
									}
								}
								System.out.printf("Dealer's Total is: %d\n", dTotal);
								dCount++;
							}
						}
						
						//if both dealer and player didn't bust, compare totals
						if(!pBust && !dBust){
								if(pTotal > dTotal)
										won = 1;
								else if(pTotal < dTotal)
										won = 0;
								else if(pTotal == dTotal)
										won = -1;
						}
						
						//after card comparison, determine winner
						if (won == 1){
							System.out.println("Player has WON! now paying player...");
							bjDealerInstance.players[0].payout = 1;
							bjDealerInstance.action = bjd_action.paying;
							num_games++;
							deal.publish(bjDealerInstance);
						}
						else if(won == -1){
							System.out.println("Player and Dealer Tie! no payout...");
							bjDealerInstance.players[0].payout = 0;
							bjDealerInstance.action = bjd_action.paying;
							num_games++;
							deal.publish(bjDealerInstance);							
						}
						else if(won == 0){
							System.out.println("Player has LOST! now collecting from player...");
							bjDealerInstance.players[0].payout = -1;
							bjDealerInstance.action = bjd_action.collecting;
							num_games++;
							deal.publish(bjDealerInstance);
						}
						System.out.println();
					}

				}


				// slight delay for the dds
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// Do nothing
				}

			}
		
	}// end of main
	// send the dealer msg to OpenSplice stream
	public void publish(bjDealer bjDealerInstance) {
		DealerPublisher our_dealer = new DealerPublisher(bjDealerInstance);
	} // end of publish


} // end of dealer class
