// The following code modified from from PrismTech HelloWorld example

/*
Group: 7
Members: Climon Galunza, Sheba Thomas, Hiumathy Lam
Date Modified: November 19, 2016
*/

import DDS.*;
import CR.*;
import java.util.*;


public class Player {
	public static int intValue(char val) {

		int total;
		// im assuming this is for the first hand?
		switch (val) {
			case 'K':  total = 10;
				break;
			case 'Q':  total =10;
				break;
			case 'J':  total =10;
				break;
			case 'T':  total =10;
				break;
			case 'A':  total = 11; // not sure how to work with the Ace values of 11 or 1 depending on the hand
				break;
			case '2':  total = 2;
				break;
			case '3':  total = 3;
				break;
			case '4':  total = 4;
				break;
			case '5':  total = 5;
				break;
			case '6':  total = 6;
				break;
			case '7':  total = 7;
				break;
			case '8':  total = 8;
				break;
			case '9':  total = 9;
				break;
			default: total = 0;
				break;
		}
		//System.out.println("Total = " + total);
		return total;
	}

	public static void main(String[] args) {
		DDSEntityManager mgr = new DDSEntityManager();
		String partitionName = "Casino Royale";
		
		// create Domain Participants
		mgr.createParticipant(partitionName);
		
		// create Types
		bjDealerTypeSupport bjDealerTS = new bjDealerTypeSupport();
		mgr.registerType(bjDealerTS);

		// create Topics
		mgr.createTopic("CR_bjDealer");
		
		// create Subscribers
		mgr.createSubscriber();

		// create DataReaders
		mgr.createReader();

		// Read Events
		DataReader dreader = mgr.getReader();
		bjDealerDataReader CRReader = bjDealerDataReaderHelper.narrow(dreader);	

		bjDealerSeqHolder bjDealerSeq = new bjDealerSeqHolder();
		SampleInfoSeqHolder infoSeq = new SampleInfoSeqHolder();		

		
		Player play = new Player(); // Dynamic class object
        
        //code to test out player (Mr. Conservative)
		bjPlayer player = new bjPlayer();     
        player.uuid = 1000;
        player.seqno = 2;
        player.credits = 100; //a player always starts with 100 credits
        player.wager = 1; //a player always wagers with the minimum number of credits
        player.dealer_id = 0;
        player.action =bjp_action.none;
		
		//play.publish(player);
		
		System.out.printf("Player ID: %d is looking for a dealer (Mr. Conservative).\n", player.uuid);
		
		int num_games = 0; //counter for number of games bot has done
		boolean first = true;
        
		
		//mainloop (break mainloop;)
		mainloop:while(true){
			CRReader.read(bjDealerSeq, infoSeq, LENGTH_UNLIMITED.value,
					ANY_SAMPLE_STATE.value, 1,
					ANY_INSTANCE_STATE.value);
			if(num_games == 5){
					player.action = bjp_action.exiting;
					System.out.println("Game over! Player has left the game.");
					break;
			}

			//for loop only works if it receives a message from dealer
			for (int i = 0; i < bjDealerSeq.value.length; i++){
				/*
				System.out.println("=== [Dealer] message received :");
				System.out.println("    uuid           : " + bjDealerSeq.value[i].uuid);
				System.out.println("    seqno          : " + bjDealerSeq.value[i].seqno);
				System.out.println("    active_players : " + bjDealerSeq.value[i].active_players);
				System.out.println("    players        : " + bjDealerSeq.value[i].players);
				System.out.println("    action         : " + bjDealerSeq.value[i].action.value());
				System.out.println("    cards          : " + bjDealerSeq.value[i].cards);
				System.out.println("    target_uuid    : " + bjDealerSeq.value[i].target_uuid);
				*/
				
				//1) if a dealer is found, try joining him
				if(bjDealerSeq.value[i].uuid != 0 && player.action.value() == 0 && first){
					System.out.println("Dealer is found!\n");
					first = false;
					System.out.printf("Your dealer is ID number %d\n", bjDealerSeq.value[i].uuid);
					player.dealer_id = bjDealerSeq.value[i].uuid;
					player.action = bjp_action.joining;
					play.publish(player);			 
				}
				
				//2) Once the dealer found the player...
				if(bjDealerSeq.value[i].active_players == 1){
						//if the player has just joined, then wager
						if(player.action == bjp_action.joining){
							player.action = bjp_action.wagering;
							System.out.printf("Player is wagering $%d\n", player.wager);
							play.publish(player);
						}
						//if the player already wagered... (Card code is here)
						//	if the dealer is dealing, then show card values
						if(player.action == bjp_action.wagering && bjDealerSeq.value[i].action.value() == 2){
							System.out.println("Dealer is now dealing the cards...\n");

							// create a class named class so that player can use the same deck
//							player.cards[0].suite = cards[0].suite;
//							player.cards[0].base_value = cards[0].base_value;
//							player.cards[0].visible = false;
//							// second card
//							player.cards[1].suite = cards[1].suite;
//							player.cards[1].base_value = cards[1].base_value;
//							player.cards[1].visible = false;
//
							// players' cards
							System.out.println("Players' Cards...");
							System.out.println(bjDealerSeq.value[i].players[0].cards[0].suite + ", " + bjDealerSeq.value[i].players[0].cards[0].base_value);
							System.out.println(bjDealerSeq.value[i].players[0].cards[1].suite + ", " + bjDealerSeq.value[i].players[0].cards[1].base_value);

							// players total
                            int pTotal = intValue(bjDealerSeq.value[i].players[0].cards[0].base_value) + intValue(bjDealerSeq.value[i].players[0].cards[1].base_value);
							int numCards = 2; // tracks number of cards

							int aces=0;
							if (bjDealerSeq.value[i].players[0].cards[0].base_value == 'A')
								aces++;
							if (bjDealerSeq.value[i].players[0].cards[1].base_value == 'A')
								aces++;

							if (pTotal > 21)                   // if two aces in a row
								if (aces > 0) {
									pTotal -= 10;
									aces--;
								}
							else if (pTotal >= 15 && pTotal < 21)	// standing
								System.out.println("STAY");
							else if (pTotal == 21) 					// 21
								System.out.println("BLACKJACK");
							System.out.println("Player has "+ pTotal); // print total

							System.out.println("Player is now deciding whether to hit or stand...\n");

							//hitting
							while (pTotal < 15) {
								// hit and total
								System.out.println("HIT ME");
								player.seqno = player.seqno + 1;
								bjDealerSeq.value[i].players[i].cards[numCards].visible = true; // change visibility
								System.out.println(bjDealerSeq.value[i].players[0].cards[numCards].suite + ", " + bjDealerSeq.value[i].players[0].cards[numCards].base_value); // print new card
								pTotal += intValue(bjDealerSeq.value[i].players[0].cards[numCards].base_value); // gets total wi/ new card
								if (bjDealerSeq.value[i].players[0].cards[numCards].base_value == 'A')
									aces++;
								if (pTotal > 21) { 							// bust
									if (aces > 0){
										pTotal -= 10;
										aces--;
									}
									else {
										System.out.println("BUST");
										break;
									}
								}
								System.out.println("Player's Total is: "+ pTotal); // prints total
								if (pTotal >= 15 && pTotal < 21) {	// else standing
									System.out.println("STAY");
									break;
								} else if (pTotal == 21){ 					// 21
									System.out.println("BLACKJACK");
									break;
								}
                                numCards++;
							}


							System.out.println("Player is ready to compare cards");
							//publish here
							player.action = bjp_action.none;
							System.out.printf("Action Value: %d\n", player.action.value());
							play.publish(player);						
						}
										
						//Dealer is now either collecting or paying
						if(bjDealerSeq.value[i].action.value() == 3){
								System.out.println("Sorry You lost!");
								player.credits--;
								System.out.printf("Player credits: %f\n\n", player.credits);
								num_games++;
								player.action = bjp_action.wagering;
								player.seqno = 2;
								play.publish(player);		
						}
						if(bjDealerSeq.value[i].action.value() == 4){
							if(bjDealerSeq.value[i].players[i].payout == 1){
								System.out.println("Congratulations! You won!");
								player.credits++;
								System.out.printf("Player credits: %f\n\n", player.credits);
								num_games++;
								player.action = bjp_action.wagering;
								player.seqno = 2;
								play.publish(player);
							}
							else if(bjDealerSeq.value[i].players[i].payout == 0){
								System.out.println("Player and Dealer Tie! No Payout!");
								System.out.printf("Player credits: %f\n\n", player.credits);
								num_games++;
								player.action = bjp_action.wagering;
								player.seqno = 2;
								play.publish(player);								
							}
						}
				}
				

			}				

			// slight delay for the dds
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// Do nothing
			}
		
		}
		
	} // end of main
        
	// send the player msg to OpenSplice stream
        //**NEED TO CREATE playerpublish file
	public void publish(bjPlayer player) {
		PlayerPublisher our_player = new PlayerPublisher(player);
	} // end of publish

} // end of player class